<?php
include ("configuration.php");
require ("utils.php");
include ("clients.php");

if (isset($_GET["action"]))
{
    $action = $_GET["action"];
    switch($action)
    {
        case "auth":
            if (isset($_GET["user"]) && isset($_GET["pass"]) && isset($_GET["client"]))
            {
                // Get args
                $user = $_GET["user"];
                $pass = $_GET["pass"];
                $client = $_GET["client"];

                // Encrypt pass
                if ($auth_pass_encrypting_dle === true)
                    $pass_enc = md5(md5($pass));
                elseif ($auth_pass_encrypting_dle === false)
                    $pass_enc = md5($pass);
                else die ("CONFIG_PROBLEM:AUTH_PASS_ENCRYPTION_DLE:MUST_BE_TRUE_OR_FALSE"); // IF not bool

                // Connect Database
                $mysql = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
                // Error catching
                if (mysqli_connect_errno())
                    die ("MYSQL_CONNECT_ERROR:".mysqli_connect_errno());

                // User auth
                // Query
                $user_auth_query = "SELECT $db_pass_column FROM $db_user_table WHERE $db_user_column='$user'";

                if ($stmt = $mysql->prepare($user_auth_query))
                {
                    $stmt->execute();
                    $stmt->bind_result($db_pass_getted);
                    while ($stmt->fetch())
                    {
                        $user_pass_db = $db_pass_getted;
                    }
                }

                // Compare passwords and do login
                if ($user_pass_db === $pass_enc)
                {
                    $sessionkey = $user . rand(1000000000, 2147483647) . rand(1000000000, 2147483647) * time();

                    // Update session

                    $session = md5($sessionkey);

                    // Updation query
                    $upd_query = "UPDATE $db_user_table SET $db_session_column='$session' WHERE $db_user_column='$user'";
                    if ($mysql->query($upd_query) !== false)
                    {
                        echo ($launcher_version);
                        echo (":");
						echo ($sessionkey);
                        echo (":");
                        echo getClientFiles($launcher_root_directory, $clients_root_directory, $client, $launcher_server_filelist_caching);
                    }
                    else die ("MYSQL_QUERY_ERROR:SESSION_UPDATE_ERROR");
                }
                else die ("BAD_LOGIN");
            }
            break;
        case "getclients":
            foreach($clients as $client => $version)
            {
                echo ($client . ":" . $version . "<br/>");
            }
            break;
    }
}