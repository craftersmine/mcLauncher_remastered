<?php
function getClientFiles($launcherDir, $clientsDir, $clientName, $caching)
{
    $bin = scandir($_SERVER['DOCUMENT_ROOT'].$clientsDir.$clientName.'/bin/');
    $mods = scandir($_SERVER['DOCUMENT_ROOT'].$clientsDir.$clientName.'/mods/');
    $coremods = scandir($_SERVER['DOCUMENT_ROOT'].$clientsDir.$clientName.'/coremods/');
    $is_exists = false;

    $files = array();
    if (file_exists($_SERVER['DOCUMENT_ROOT'].$launcherDir.'/temp/'.$clientName.'.listing') == true)
    {
        $is_exists = true;
        return file_get_contents($_SERVER['DOCUMENT_ROOT'].$launcherDir.'/temp/'.$clientName.'.listing');
    }

    foreach ($bin as $value)
    {

        if ($value != "." && $value != "..") {
            //$md5file = md5_file($_SERVER['DOCUMENT_ROOT'].$clients_dir.$clientName.'/bin/'.$value);
            array_push($files, '/bin/' . $value . '|');
            echo('/bin/' . $value . '|');
        }
    }
    foreach ($mods as $mod)
    {
        //$md5file = md5_file($_SERVER['DOCUMENT_ROOT'].$clients_dir.$clientName.'/mods/'.$mod);
        if ($mod != "." && $mod != "..") {
            array_push($files, '/mods/' . $mod . '|');
            echo('/mods/' . $mod . '|');
        }
    }
    foreach ($coremods as $coremod)
    {
        //$md5file = md5_file($_SERVER['DOCUMENT_ROOT'].$clients_dir.$clientName.'/coremods/'.$coremod);
        if ($coremod != "." && $coremod != "..") {
            array_push($files, '/coremods/' . $coremod . '|');
            echo('/coremods/' . $coremod . '|');
        }
    }
//$md5file = md5_file($_SERVER['DOCUMENT_ROOT'].$clients_dir.$clientName.'/client.zip');
    echo ('/client.zip');
    array_push($files, '/client.zip');
    if ($caching)
    {
        if($is_exists === false)
        {
            file_put_contents($_SERVER['DOCUMENT_ROOT'].$launcherDir.'/temp/'.$clientName.'.listing', $files);
            return file_get_contents($_SERVER['DOCUMENT_ROOT'].$launcherDir.'/temp/'.$clientName.'.listing');
        }
    }
    else
    {
        $list = "";
        foreach ($files as $file)
        {
            $list = $list . "$file|";
        }
        return $list;
    }
}