<?php
define('INCLUDE_CHECK',true);
include ("configuration.php");

$sessionid = $_GET['sessionId'];
$user = $_GET['user'];
$serverid = $_GET['serverId'];

$mysql = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
$result = mysqli_query($mysql,"Select $db_user_column From $db_user_table Where $db_session_column='$sessionid' And $db_user_column='$user' And $db_server_column='$serverid'") or die ("Запрос к базе завершился ошибкой.");

if(mysqli_num_rows($result) == 1){
    echo "OK";
} else {

$result = mysqli_query($mysql,"Update $db_user_table SET $db_server_column='$serverid' Where $db_session_column='$sessionid' And $db_user_column='$user'") or die ("Запрос к базе завершился ощибкой.");

    if(mysqli_affected_rows($mysql) == 1){
        echo "OK";
    } else {
        echo "Bad login";
    }
}
?>