<?php
define('INCLUDE_CHECK',true);
include ("configuration.php");

$user = $_GET['user'];
$serverid = $_GET['serverId'];

$mysql = mysqli_connect($db_host,$db_user,$db_pass,$db_name);

$result = mysqli_query($mysql,"Select $db_user_column From $db_user_table Where $db_user_column='$user' And $db_server_column='$serverid'") or die ("Запрос к базе завершился ошибкой.");

if(mysqli_num_rows($result) == 1){
    echo "YES";
} else{
    echo "NO";
}

?>